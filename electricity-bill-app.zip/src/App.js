import React, { useState } from "react";

export default function App() {
  const [message, setMessage] = useState("Electricity Bill Bifurcation");

  return (
    <div className="p-6 max-w-xl mx-auto text-center">
      <h1 className="text-xl font-bold mb-4">{message}</h1>
      <p>App content will go here...</p>
    </div>
  );
}